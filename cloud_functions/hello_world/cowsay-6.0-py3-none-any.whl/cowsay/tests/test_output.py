import io
import sys
from typing import Callable

import pytest

from cowsay import char_funcs, char_names
from . import solutions


def capture_output(function: Callable, arguments: str) -> str:
    captured_output = io.StringIO()
    sys.stdout = captured_output
    function(arguments)
    sys.stdout = sys.__stdout__
    captured_output.seek(0)
    return captured_output.read()


def delete_empty_lines(data):
    new_data = []
    for line in data.splitlines():
        if len(line.strip()) > 0:
            new_data.append(line.rstrip())
    return new_data


@pytest.mark.parametrize('char', char_names, ids=char_names)
def test_char_solution(char):

    lorem: str = (
        'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam'
        'nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat,'
        'sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.'
    )

    output = capture_output(char_funcs[char], lorem)
    output = delete_empty_lines(output)
    solution = delete_empty_lines(solutions.CHARS_SOLUTIONS[char])
    assert output == solution
